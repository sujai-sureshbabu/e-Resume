import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'awards-component',
  templateUrl: './awards.component.html',
  styleUrls: ['./awards.component.css']
})
export class AwardsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
