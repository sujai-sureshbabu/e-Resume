import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'interests-component',
  templateUrl: './interests.component.html',
  styleUrls: ['./interests.component.css']
})
export class InterestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
